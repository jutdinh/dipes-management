export default () => {
    return(
        <span>Sign Up </span>
    )
}