import Projects from "./projects";
import ProjectDetail from "./projectcard-detail";
import TaskDetail from "./task-detail";

export {
    Projects,
    ProjectDetail,
    TaskDetail
}