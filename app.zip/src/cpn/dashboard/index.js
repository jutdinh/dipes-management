import Home from "./home";
import About from './about';
export {
    Home,
    About
}