import Statistical from './static'


export {
    Statistical
}