import Vi from './vi';
import En from './en';

export default {
    Vi, En
}